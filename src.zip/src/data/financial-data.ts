export const course = {
  "code": "ICC ACCTG 120",
  "name": "Financial Accounting",
  "description": "Chapter-by-chapter videos, worked problems, downloadable problem data, and solutions.",
  "chapters": [
    {
      "number": "1",
      "title": "Financial Accounting and Basic Financial Statements",
      "items": [
        {
          "title": "Financial Accounting",
          "url": "https://go.screenpal.com/watch/cOjrl4nvNzo",
          "type": "video"
        },
        {
          "title": "Problem: Basic Financial Statements",
          "url": "https://go.screenpal.com/watch/cOjrbnnv86z",
          "type": "video"
        }
      ]
    },
    {
      "number": "2",
      "title": "Debits, Credits, and the Balance Sheet",
      "items": [
        {
          "title": "Debits and Credits",
          "url": "https://go.screenpal.com/watch/cOjrDPnv8QC",
          "type": "video"
        },
        {
          "title": "The Balance Sheet",
          "url": "https://go.screenpal.com/watch/cOjrbFnv8Ib",
          "type": "video"
        },
        {
          "title": "Problem: Journal Entries and Balance Sheet - New Company",
          "url": "https://go.screenpal.com/watch/cOjrbjnv8Xv",
          "type": "video"
        },
        {
          "title": "Problem: Journal Entries, Trial Balance, and Balance Sheet - Established Company",
          "url": "https://go.screenpal.com/watch/cOjrqOnv8xY",
          "type": "video"
        },
        {
          "title": "Problem Data",
          "url": "/pdfs/acctg120/ch02-journal-entries-trial-balance-balance-sheet-established-company-problem.pdf",
          "type": "file"
        },
        {
          "title": "Solution",
          "url": "/pdfs/acctg120/ch02-journal-entries-trial-balance-balance-sheet-established-company-solution.pdf",
          "type": "file"
        }
      ]
    },
    {
      "number": "3",
      "title": "The Income Statement",
      "items": [
        {
          "title": "The Income Statement",
          "url": "https://go.screenpal.com/watch/cOjrbInv8lw",
          "type": "video"
        },
        {
          "title": "Problem: Journal Entries and Income Statement",
          "url": "https://go.screenpal.com/watch/cOjrqrnv8wg",
          "type": "video"
        },
        {
          "title": "PDF Problem Data",
          "url": "/pdfs/acctg120/ch03-journal-entries-income-statement-problem.pdf",
          "type": "file"
        },
        {
          "title": "PDF Solution",
          "url": "/pdfs/acctg120/ch03-journal-entries-income-statement-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Exercise 3-13 from textbook",
          "url": "https://go.screenpal.com/watch/cOjrqXnv8vQ",
          "type": "video"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch03-textbook-exercise-3-13-solution.pdf",
          "type": "file"
        }
      ]
    },
    {
      "number": "4",
      "title": "Adjusting Entries and the Closing Process",
      "items": [
        {
          "title": "Adjusting Journal Entries",
          "url": "https://go.screenpal.com/watch/cOjuqmnwXlT",
          "type": "video"
        },
        {
          "title": "The Closing Process",
          "url": "https://go.screenpal.com/watch/cOjuqKnwXlL",
          "type": "video"
        },
        {
          "title": "Problem: Adjusting Journal Entries",
          "url": "https://go.screenpal.com/watch/cOjuqsnwXII",
          "type": "video"
        },
        {
          "title": "PDF Problem Data",
          "url": "/pdfs/acctg120/ch04-adjusting-journal-entries-problem.pdf",
          "type": "file"
        },
        {
          "title": "PDF Adjusted Trial Balance Solution",
          "url": "/pdfs/acctg120/ch04-adjusting-journal-entries-adjusted-trial-balance-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Financial Statements, Closing Entries, and Post-closing Trial Balance",
          "url": "https://go.screenpal.com/watch/cOjuqNnwXIy",
          "type": "video"
        },
        {
          "title": "PDF Post Closing Trial Balance Solution",
          "url": "/pdfs/acctg120/ch04-financial-statements-closing-entries-post-closing-trial-balance-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Complete Accounting Cycle",
          "label": "Part 1: Journal Entries and T-Accounts",
          "url": "https://go.screenpal.com/watch/cOjUIdnwlbR",
          "type": "video"
        },
        {
          "title": "Problem Data",
          "url": "/pdfs/acctg120/ch04-complete-accounting-cycle-problem.pdf",
          "type": "file"
        },
        {
          "title": "Solution",
          "url": "/pdfs/acctg120/ch04-complete-accounting-cycle-solution.pdf",
          "type": "file"
        },
        {
          "title": "Video 2 - Unadjusted Trial Balance and Adjusting Entries",
          "label": "Part 2: Unadjusted Trial Balance and Adjusting Entries",
          "url": "https://go.screenpal.com/watch/cOjUIsnwlFo",
          "type": "video"
        },
        {
          "title": "Video 3 - Adjusted Trial Balance and Financial Statements",
          "label": "Part 3: Adjusted Trial Balance and Financial Statements",
          "url": "https://go.screenpal.com/watch/cOjUIPnwlFU",
          "type": "video"
        },
        {
          "title": "Video 4 - Closing Entries and Post-Closing Trial Balance",
          "label": "Part 4: Closing Entries and Post-Closing Trial Balance",
          "url": "https://go.screenpal.com/watch/cOjU2enwlFK",
          "type": "video"
        }
      ]
    },
    {
      "number": "6",
      "title": "Inventory Purchases, Sales, and Multi-Step Income Statements",
      "items": [
        {
          "title": "Inventory Purchase and Sale Entries/ Multi-step Income Statements",
          "url": "https://go.screenpal.com/watch/cOjwcKnwoON",
          "type": "video"
        },
        {
          "title": "Problem: Inventory Purchase & Sale Entries",
          "url": "https://go.screenpal.com/watch/cOjwcPnwouG",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch06-inventory-purchase-sale-entries-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch06-inventory-purchase-sale-entries-solution.pdf",
          "type": "file"
        }
      ]
    },
    {
      "number": "7",
      "title": "Inventory Costing",
      "items": [
        {
          "title": "Inventory Costing",
          "url": "https://go.screenpal.com/watch/cOQDVHnwNpK",
          "type": "video"
        },
        {
          "title": "Problem: Inventory Costing",
          "url": "https://go.screenpal.com/watch/cOQDVgnwNpI",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch07-fifo-lifo-weighted-average-inventory-costing-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch07-fifo-lifo-weighted-average-inventory-costing-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: LCM",
          "url": "https://go.screenpal.com/watch/cOQDVanwNk9",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch07-lower-of-cost-or-market-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch07-lower-of-cost-or-market-solution.pdf",
          "type": "file"
        }
      ]
    },
    {
      "number": "8",
      "title": "Receivables and Bad Debts",
      "items": [
        {
          "title": "Extending Credit and Accounting for Bad Debts",
          "url": "https://go.screenpal.com/watch/cOQDlgnw8pz",
          "type": "video"
        },
        {
          "title": "Notes Receivable",
          "url": "https://go.screenpal.com/watch/cOQDlLnw8Ec",
          "type": "video"
        },
        {
          "title": "Problem: Allowance Method Entries",
          "url": "https://go.screenpal.com/watch/cOQDlPnw8E4",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch08-bad-debts-allowance-method-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch08-bad-debts-allowance-method-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Notes Rec Interest Due at Maturity",
          "url": "https://go.screenpal.com/watch/cOQDI1nw8GJ",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch08-notes-receivable-interest-at-maturity-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch08-notes-receivable-interest-at-maturity-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Notes Rec Interest Accrued Every Quarter",
          "url": "https://go.screenpal.com/watch/cOQDIenw8G3",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch08-notes-receivable-quarterly-interest-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch08-notes-receivable-quarterly-interest-solution.pdf",
          "type": "file"
        }
      ]
    },
    {
      "number": "9",
      "title": "Long-Term Assets and Depreciation",
      "items": [
        {
          "title": "Long Term Assets and Depreciation",
          "url": "https://go.screenpal.com/watch/cOQDIvnw8dS",
          "type": "video"
        },
        {
          "title": "Other Long Term Asset Topics",
          "url": "https://go.screenpal.com/watch/cOQDIOnw8dZ",
          "type": "video"
        },
        {
          "title": "Problem: Depreciation",
          "url": "https://go.screenpal.com/watch/cOQDIrnw8J2",
          "type": "video"
        },
        {
          "title": "(PDF Problem)",
          "url": "/pdfs/acctg120/ch09-straight-line-units-of-production-declining-balance-depreciation-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch09-straight-line-units-of-production-declining-balance-depreciation-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Disposals",
          "url": "https://go.screenpal.com/watch/cOQDIFnw8HG",
          "type": "video"
        },
        {
          "title": "(PDF Problem)",
          "url": "/pdfs/acctg120/ch09-plant-asset-disposals-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch09-plant-asset-disposals-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Changes in Depreciation",
          "url": "https://go.screenpal.com/watch/cOQDIlnw8mK",
          "type": "video"
        },
        {
          "title": "(PDF Problem)",
          "url": "/pdfs/acctg120/ch09-change-in-depreciation-estimate-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch09-change-in-depreciation-estimate-solution.pdf",
          "type": "file"
        }
      ]
    },
    {
      "number": "10",
      "title": "Liabilities",
      "items": [
        {
          "title": "Liabilities",
          "url": "https://youtu.be/DBkdDLoi8zM",
          "type": "video"
        },
        {
          "title": "Notes Payable",
          "url": "https://youtu.be/qTy2dwpzBOc",
          "type": "video"
        },
        {
          "title": "Installment Notes",
          "url": "https://youtu.be/WC97A7TKlHU",
          "type": "video"
        },
        {
          "title": "Bonds Payable",
          "url": "https://youtu.be/Hdwnw-QJjPw",
          "type": "video"
        },
        {
          "title": "Problem: Notes Payable Interest Due at Maturity",
          "url": "https://youtu.be/_gfyITYO2Aw",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch10-notes-payable-interest-at-maturity-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch10-notes-payable-interest-at-maturity-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Notes Payable Interest Accrued Every Quarter",
          "url": "https://youtu.be/NYZrXRKkMXE",
          "type": "video"
        },
        {
          "title": "(PDF Problem data)",
          "url": "/pdfs/acctg120/ch10-notes-payable-quarterly-interest-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch10-notes-payable-quarterly-interest-solution.pdf",
          "type": "file"
        },
        {
          "title": "Problem: Installment Note",
          "url": "https://youtu.be/QwBUgQTEeqQ",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch10-installment-note-payable-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch10-installment-note-payable-solution.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Loan Amortization Schedule)",
          "url": "/pdfs/acctg120/ch10-installment-note-loan-amortization-schedule.pdf",
          "type": "file"
        },
        {
          "title": "My Calculators Tool",
          "url": "https://www.mycalculators.com/ca/home.html",
          "type": "tool"
        }
      ]
    },
    {
      "number": "11",
      "title": "Stockholders’ Equity",
      "items": [
        {
          "title": "Stockholders' Equity",
          "url": "https://youtu.be/5mtcMTbO6oc",
          "type": "video"
        },
        {
          "title": "Problem: Stock Issuance, Treasury Stock, Dividends, and SE section of the Balance Sheet",
          "url": "https://youtu.be/HIyh-Dixbs0",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch11-stockholders-equity-transactions-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch11-stockholders-equity-transactions-solution.pdf",
          "type": "file"
        }
      ]
    },
    {
      "number": "12",
      "title": "Statement of Cash Flows",
      "items": [
        {
          "title": "Statement of Cash Flows",
          "url": "https://youtu.be/jh2uOKeRK-Q",
          "type": "video"
        },
        {
          "title": "Statement of Cash Flows Problem",
          "url": "https://youtu.be/kT5rYFMVPGQ",
          "type": "video"
        },
        {
          "title": "(PDF Problem Data)",
          "url": "/pdfs/acctg120/ch12-statement-of-cash-flows-indirect-method-problem.pdf",
          "type": "file"
        },
        {
          "title": "(PDF Solution)",
          "url": "/pdfs/acctg120/ch12-statement-of-cash-flows-indirect-method-solution.pdf",
          "type": "file"
        }
      ]
    }
  ]
} as const;
